import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { once } from 'node:events';
import { mkdtemp, rmdir, unlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { createLessonServer, lessonPath, videoFrame } from '../server.mjs';

const commentsPath = lessonPath + '/comments';
const moderationPath = lessonPath + '/moderation';

async function runServer(options) {
  const server = createLessonServer(options);
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = 'http://127.0.0.1:' + server.address().port;
  return {
    fetch: (path, options) => fetch(base + path, { redirect: 'manual', ...options }),
    post(path, fields, options = {}) {
      const headers = { Origin: base, 'Content-Type': 'application/json', ...options.headers };
      return this.fetch(path, { method: 'POST', headers, body: JSON.stringify(fields) });
    },
    close: () => new Promise(resolve => server.close(resolve)),
  };
}

test('guests and crawlers receive the full lesson, video, thumbnail and canonical sitemap', async (t) => {
  const web = await runServer({ databasePath: ':memory:' });
  t.after(web.close);
  const page = await web.fetch(lessonPath, { headers: { 'User-Agent': 'Googlebot' } });
  assert.equal(page.status, 200);
  const markup = await page.text();
  const canonical = 'https://skill-up.ir' + lessonPath;
  assert.ok(markup.includes('<link rel="canonical" href="' + canonical + '">'));
  assert.ok(markup.includes('src="' + videoFrame.replaceAll('&', '&amp;') + '"'));
  assert.match(markup, /loading="eager"[^>]+allowfullscreen/);
  assert.match(markup, /<h1[^>]+>ساخت انیمیشن در اسکرچ/);
  assert.match(markup, /animation-blocks-approved\.png/);
  assert.ok(markup.indexOf('id="lab"') < markup.indexOf('id="summary"'));
  assert.equal((await web.fetch(lessonPath + '/assets/animation-blocks-approved.png')).headers.get('content-type'), 'image/png');
  assert.doesNotMatch(markup, /\{\{[A-Z_]+\}\}/);
  assert.match(page.headers.get('content-security-policy'), /frame-src https:\/\/www.aparat.com/);
  const schema = JSON.parse(markup.match(/<script type="application\/ld\+json">(.+?)<\/script>/s)[1]);
  const video = schema['@graph'].find(item => item['@type'] === 'VideoObject');
  assert.equal(video.duration, 'PT10M31S');
  assert.equal(video.embedUrl, videoFrame);
  assert.ok(video.thumbnailUrl.startsWith(canonical));
  assert.equal((await web.fetch(new URL(video.thumbnailUrl).pathname)).headers.get('content-type'), 'image/jpeg');
  const sitemap = await web.fetch('/learn/scratch/sitemap.xml');
  assert.match(sitemap.headers.get('content-type'), /^application\/xml/);
  assert.ok((await sitemap.text()).includes('<loc>' + canonical + '</loc>'));
  assert.equal((await web.fetch(lessonPath + '/')).headers.get('location'), lessonPath);
  assert.equal((await web.fetch('/courses')).status, 404);
});

test('a comment persists, stays private before approval and can be withdrawn', async (t) => {
  const directory = await mkdtemp(join(tmpdir(), 'skillup-lesson-test-'));
  const databasePath = join(directory, 'comments.sqlite');
  const adminToken = randomBytes(24).toString('hex');
  let web = await runServer({ databasePath, adminToken });
  t.after(async () => {
    await web.close();
    for (const path of [databasePath, databasePath + '-wal', databasePath + '-shm']) {
      await unlink(path).catch(error => { if (error.code !== 'ENOENT') throw error; });
    }
    await rmdir(directory);
  });
  const input = { name: 'آرین', body: 'دو حالت گربه را ساختم و سرعت پرش را تغییر دادم.' };
  assert.equal((await web.post(commentsPath, input)).status, 201);
  assert.equal((await web.post(commentsPath, input)).status, 201);
  assert.deepEqual(await (await web.fetch(commentsPath)).json(), { comments: [], next: null });
  assert.equal((await web.post(moderationPath + '/update', { id: '1', from: 'pending', to: 'approved' })).status, 401);
  await web.close();
  web = await runServer({ databasePath, adminToken });
  const login = await web.post(moderationPath + '/login', { password: adminToken });
  assert.equal(login.status, 303);
  assert.match(login.headers.get('set-cookie'), /HttpOnly; SameSite=Strict/);
  const headers = { Cookie: login.headers.get('set-cookie').split(';')[0] };
  const pending = await web.fetch(moderationPath, { headers });
  assert.equal(pending.headers.get('x-robots-tag'), 'noindex, nofollow');
  assert.equal((await pending.text()).split(input.body).length, 2);
  assert.equal((await web.post(moderationPath + '/update', { id: '1', from: 'pending', to: 'approved' }, { headers })).status, 303);
  const { comments } = await (await web.fetch(commentsPath)).json();
  assert.equal(comments.length, 1);
  assert.deepEqual({ name: comments[0].name, body: comments[0].body }, input);
  assert.equal((await web.post(moderationPath + '/update', { id: '1', from: 'pending', to: 'rejected' }, { headers })).status, 409);
  assert.equal((await web.post(moderationPath + '/update', { id: '1', from: 'approved', to: 'rejected' }, { headers })).status, 303);
  assert.deepEqual((await (await web.fetch(commentsPath)).json()).comments, []);
  assert.equal((await web.post(moderationPath + '/logout', {}, { headers })).status, 303);
  assert.match(await (await web.fetch(moderationPath, { headers })).text(), /name="password"/);
});

test('form rejects off-site requests, invalid data and contact information', async (t) => {
  const web = await runServer({ databasePath: ':memory:' });
  t.after(web.close);
  const normal = { name: 'گربه‌ساز', body: 'انیمیشن را برای پروژهٔ خودم تمرین کردم.' };
  assert.equal((await web.post(commentsPath, normal, { headers: { Origin: 'https://another.example' } })).status, 403);
  assert.equal((await web.post(commentsPath, { ...normal, name: ' ' })).status, 422);
  assert.equal((await web.post(commentsPath, { ...normal, body: 'تلفن ۰۹۱۲۳۴۵۶۷۸۹ است.' })).status, 422);
  assert.equal((await web.post(commentsPath, { ...normal, body: 'ایمیل sample@example.net را وارد کردم.' })).status, 422);
  assert.equal((await web.post(commentsPath, { ...normal, body: 'س'.repeat(8000) })).status, 413);
  const native = new URLSearchParams(normal);
  const htmlResponse = await web.fetch(commentsPath, { method: 'POST',
    headers: { Origin: 'https://skill-up.ir' }, body: native });
  assert.equal(htmlResponse.status, 201);
  assert.match(await htmlResponse.text(), /دیدگاهت ثبت شد/);
});
